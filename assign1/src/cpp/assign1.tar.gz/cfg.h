#ifndef CFG_H
#define CFG_H
#include <stdio.h>
extern "C" {
	#include <simple.h>
}

#include <vector>
#include <map>
#include <iostream>
#include <set>

using namespace std;
class BasicBlock {
	friend ostream &operator<<(ostream &, const BasicBlock &);
	

	public:
		int instrNum;
		int blockNum;
		int startNum;
		int endNum;
		set <int> dom;
		set <int> iDom; 
		map<int,int> preb;
		map<int,int> succ;
		BasicBlock();
		BasicBlock(int instrNum, int start, int end);
		
		void addPreb(int blockIndex);
		void addSucc(int blockIndex);
		int operator== (const BasicBlock &rhs) const;
		int operator< (const BasicBlock &rhs) const;
};
		
		
	
class CFG {
	map <int, BasicBlock> cfgMap;
	int totalInstrNum;
	int totalBlockNum;
	void addBlock(int,int,int);
	void iniBasicBlock(simple_instr *, map<int,int> &);
	int buildLeadVector(simple_instr *, map<int,int> &);
	void buildCFG(simple_instr *inlist);
	int findBasicBlockInstr(int instrIndex);
	void findDom();


	public:
		int getTotalBlockNum(){return totalBlockNum;}
		void printBlock();
		CFG(simple_instr *inlist);
		void findIDom();
		void printIDom();

		
		

};

#endif




	


